# SA Calculator v1.97.1-v97.1 — Video-driven scientific result audit

## Input reviewed
- Base archive: `SA-Calculator-v92-RELIABILITY-HARDENED-v1.95.0.zip`.
- User recording: `Screenrecording_20261114_115429.mp4` (720 × 1560, approximately 40.5 seconds).
- Source inspected: `assets/js/app.js`, calculator parser, live-preview gate, committed-result continuation, scientific function insertion, editor token handling and result rendering.

## Findings grounded in the recording

1. At approximately 14 seconds, the committed result is displayed as `8.337478 × 10¹⁷`.
2. At approximately 16 seconds, tapping the square-root function changes the expression to a radical over that scientific result, but the live result row shows `Error`.
3. At approximately 18 seconds, a further scientific-function interaction also leaves an Error preview. This is consistent with the same insertion-state defect, not proof of a separate parser failure.
4. At approximately 28 seconds, `9^99` produces `2.951267 × 10⁹⁴`, which is within JavaScript's finite Number range.
5. At approximately 30 seconds, `9^999` displays `Error`; at approximately 36 seconds, `9^9999` remains Error. Both exceed the finite IEEE-754 JavaScript Number range. This is a documented engine range limitation, not a valid finite Number result. Arbitrary-precision exponentiation is not included in this patch.

## Root cause

`insertScientificFunction()` set `STATE.calcScientificErrorPreview = true` for successful scientific-key insertions. `evaluateLiveExpression()` checks this flag before the parser and therefore returned the literal `Error` even when the expression was valid and evaluable. The source comments described this as an intentional preview contract, but the supplied recording demonstrates the resulting user-visible failure for a valid radical applied to a committed result.

A second correctness risk existed in continuation: a scientific result is displayed as a rounded mantissa/exponent token while the original `STATE.calcRawValue` carries more precision. The old continuation substitution only recognized the token at the start of the expression, so wrapping the token in a function could discard the full-precision mapping.

## Changes in v1.97.1-v97.1

- Removed forced preview errors from successful scientific-key insertions. The common parser now decides between a real numeric preview, an incomplete expression, and a genuine mathematical/syntax error.
- Added `buildScientificResultExpression()` so a scientific function tapped after `=` acts on the committed answer, not on the hidden source expression. Square root, cube root, trigonometric/logarithmic functions, reciprocal, factorial, percent, power and pi actions have explicit expression construction.
- Extended exact-value continuation to replace an unchanged scientific display token wherever it appears, including inside a function wrapper such as `√(8.337478 × 10¹⁷)`.
- Scientific display tokens remain atomic for operand selection. Editing the token invalidates the old exact-value continuation metadata.
- Bumped package, manifest, UI, feedback and service-worker cache identity to `1.97.1-v97.1`.
- Added seven focused regression tests, including an integration-level test that taps square root after a committed scientific result.

## Verification

- Full automated suite: **115 passed, 0 failed, 0 skipped**.
- JavaScript syntax checks: passed for all runtime JS files, server and service worker.
- CSS parser: 2,379 top-level rules, 0 parse errors.
- HTML audit: no duplicate IDs; all local `src`/`href` assets resolve.
- JSON validation: package, manifest and localization inventories parse; package and manifest versions agree.
- Local HTTP smoke: app shell, runtime JS, theme bootstrap, localization JS, CSS, manifest and service worker all returned HTTP 200. HEAD returned 200 with a content length and no body.
- ZIP integrity checked after packaging.

## Explicit limitations

- `9^999` and `9^9999` exceed JavaScript Number's finite range. They remain safely rejected; this release does not claim arbitrary-precision arithmetic.
- Automated Node/source tests do not replace replaying the exact interaction on the user's Android/Acode WebView. Device-specific rendering, touch behavior, screen-reader behavior and performance profiling remain unverified here.
- No zero-lag or zero-bug guarantee is made.


## v1.97.2-v97.2 — overflow-safe radical-of-power evaluation (2026-11-14)

A supplied Android screen recording showed `∛9^966` producing `Error` even though its final cube-root value (`9^322`) is within the finite IEEE-754 Number range. The parser previously evaluated `9^966` first, overflowed to Infinity, and rejected the expression before applying the cube root.

The leading radical parser now evaluates an unparenthesized power as `base^(exponent / degree)` for square/cube roots, preserving the finite-result case while continuing to reject genuinely out-of-range final results and invalid square-root domains. Regression coverage includes live preview, committed evaluation, negative cube-root sign, square-root domain rejection, and a still-overflowing cube-root case.

## v1.97.4-v97.4 — memory and parenthesized scientific-root integrity (2026-11-14)

- Added runtime regression coverage for MC/MR/MS/M+/M−, persistence, empty/corrupt storage, invalid inputs, and recall-state cleanup.
- Fixed parenthesized radical powers such as `∛(9^966)` and `√(9^324)` so a finite final root is evaluated without first overflowing the radicand.
- Added regression coverage for compact and parenthesized radical forms, overflow boundaries, and live preview.
- Bumped the app and service-worker cache version to prevent stale scripts from masking the fix.
