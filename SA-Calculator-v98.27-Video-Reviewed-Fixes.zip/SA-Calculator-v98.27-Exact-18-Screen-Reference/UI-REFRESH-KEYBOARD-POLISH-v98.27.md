# SA Calculator v98.27 — Screenshot-led UI and on-demand tool keypad

## Implemented
- Kept the basic calculator's keypad permanently visible.
- Switched every tool destination to the shared popup keypad, opened only after the user taps an editable numeric field.
- Removed automatic first-field activation when entering a tool, so tool screens start without a visible or selected keyboard.
- Hid persistent dock keypads on non-calculator screens to prevent duplicate keyboard surfaces.
- Unified tool surfaces around the supplied midnight-navy, blue-action and green-result reference palette.
- Standardized tool toolbar, cards, field sizing, result panels and popup keypad styling.
- Preserved existing field IDs, calculation handlers, conversion engines, currency refresh logic and screen destinations.

## Verification
- Existing automated regression suite plus new on-demand-keyboard regression tests.
- Web bundle generation and archive integrity.
- Physical Android APK installation and visual pixel comparison remain device/CI release gates; they are not claimed as completed here.
