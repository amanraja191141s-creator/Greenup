# v98.27 Converter Reference Audit

## Reference details implemented
- Currency: full-width source currency row with flag, ISO code and localized currency name; full-width source amount; central swap; destination currency row; green converted amount; rate note/status/last refresh; explicit Convert action.
- Units: full-width category selector; full-width source unit selector; full-width editable value; central swap; full-width destination unit selector; prominent green result; explicit Convert action.
- Currency Convert calls the existing `calcCurrency()` precision/rate path and refits both amount displays. Unit Convert calls the existing `calcUnits()` path. No alternate arithmetic engine was introduced.
- Existing IDs for selectors, keypad, values, and results are retained. Currency auto-refresh, cached rates, offline fallback, pair persistence and unit category definitions are retained.

## Version/cache
- package version: `1.98.27-v98.27`
- Android versionCode: `1098027`
- service worker cache: `sa-calculator-v98-27-converter-reference-layout`
- workflow expected source version: `1.98.27-v98.27`

## Verification limits
This source-level audit does not claim pixel-perfect identity or zero bugs on every Android device. The GitHub Actions Gradle APK build and physical-device screenshots/touch testing must pass before calling the APK verified.

- Default reference state: USD → EUR with amount 100; Length category with Meter (m) → Kilometer (km), value 1. Existing saved currency pairs remain preferred over defaults.
- Discount and Percent now have full-width reference-style fields, green result surfaces, explicit Calculate actions, and a mode selector that preserves both percentage-of and percent-change workflows.
