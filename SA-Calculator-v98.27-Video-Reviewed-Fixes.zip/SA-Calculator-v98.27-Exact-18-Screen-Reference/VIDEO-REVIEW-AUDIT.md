# SA Calculator v98.27 — Video Review & Fix Report

## Source reviewed
- Screen recording: `Screenrecording_20261117_063417.mp4`
- Duration: approximately 1 minute 43 seconds
- Resolution: 720 × 1560
- Source project: `SA-Calculator-v98.27-Screenshot-UI-On-Demand-Keyboard.zip`

## Reproducible visual/interaction issues observed

1. **Obsolete tool-screen header artifact** — a narrow blue rounded strip is visible above the actual tool toolbar across multiple screens. The CSS contained legacy pseudo-element title/menu treatments in addition to the real reference toolbar. The pseudo header/menu are now explicitly disabled so the real toolbar is the single header.
2. **Currency selector composition** — the currency flag, code, currency name and dropdown affordance do not sit on a stable common layout in the recording; the flag appears displaced relative to the code. The selector now uses explicit grid tracks and a full-size transparent native select for touch selection.
3. **Settings controls appear collapsed/clipped** — multiple Settings groups show only shallow horizontal control/card strips, with labels and controls missing or partially visible. Settings cards/rows/label groups/selects now have explicit flex sizing, auto height, visible overflow and scroll behavior.
4. **Loan amortization table is clipped at the right edge** — the recording shows only part of the Interest column and does not expose the Balance column without horizontal movement. The table now has a stable minimum width and a touch-scrollable horizontal wrapper; all five columns remain reachable.
5. **Date-event dialog competes with the native keyboard** — when editing an event name, the dialog extends behind the Android keyboard and its lower actions are not readily visible. The dialog card now scrolls within the dynamic viewport and its action row remains sticky.
6. **Fuel Efficiency label bands** — input labels sit on mismatched dark rectangular strips rather than the shared transparent form surface. The form rows and labels now use a consistent transparent layout.
7. **Narrow-screen horizontal overflow risk** — dense tool cards and long labels can push content beyond the screen width. Shared tool screen/card containers now enforce min-width:0 and horizontal overflow containment.

## Keyboard behavior observed
- The Basic Calculator keeps its calculator keypad visible.
- Other tool screens do not show a keypad by default.
- The numeric popup keypad appears after focusing a numeric tool input; text entry (for example, an event name) invokes the native Android keyboard. This is the intended on-demand behavior and was preserved.

## Changes made
- Appended narrowly scoped Android/WebView CSS corrections to `assets/css/app.css`.
- Regenerated the Android web bundle with `npm run build:web`.
- Added `tests/video-review-layout.test.js` covering the pseudo-header, Settings layout, currency selector, amortization scrolling, date-dialog keyboard behavior, Fuel Efficiency label styling and source/bundle stylesheet parity.
- Kept the existing calculation engines and business logic unchanged.

## Verification performed
- `npm run build:web`: PASS; 10 required web assets verified.
- `npm test`: PASS; 211 tests, 0 failures.
- JavaScript syntax: existing app source unchanged; no new JavaScript was introduced.
- ZIP integrity: verified after packaging.
- Workflow copies: synchronized with `.github/workflows/main.yml`.

## Not certified in this pass
- A physical Android APK build/install was not run in this environment.
- The fixes have not been re-recorded on the user's physical phone; therefore pixel-perfect rendering, live provider reachability and zero-lag/zero-bug behavior cannot honestly be guaranteed from source tests alone.
