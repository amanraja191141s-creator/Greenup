# SA Calculator v98.26 — Build Verification

## Release identity
- Package/app/PWA version: `1.98.27-v98.27`
- Android versionCode: `1098027` (derived by `scripts/patch-android-native.mjs` from the package version)
- Service-worker cache: `sa-calculator-v98-27-converter-reference-layout`
- GitHub workflow copies: `.github/workflows/main.yml`, `android-apk.yml`, and `main-v98.26-exact-18-screen-reference.yml` are byte-identical.

## Local verification
- `npm test`: **199 passed, 0 failed**.
- JavaScript syntax: passed for `app.js`, localization scripts, theme bootstrap, server, service worker and Android scripts.
- `npm run build:web`: passed; 10 required Android web assets generated and verified.
- Workflow YAML: all three copies parsed successfully.
- Release identity: package, HTML, runtime, PWA manifest, service worker and workflow version checks passed.

## Not yet verified
- Android Gradle `assembleDebug` was not run in this local environment because no Android project/SDK build was provisioned here; GitHub Actions performs project generation, Capacitor sync, native branding/inset patching, Gradle build and APK identity/checksum verification.
- No APK was installed on a physical Android device in this run.
- No physical-device screenshot/pixel comparison, touch-latency test, or battery/network/status-bar test was completed.

**Release status:** source and web bundle pass local automated checks. APK build and physical-device UI verification remain required. No guarantee of pixel-perfect rendering, zero bugs or lag-free operation is claimed before those checks pass.
