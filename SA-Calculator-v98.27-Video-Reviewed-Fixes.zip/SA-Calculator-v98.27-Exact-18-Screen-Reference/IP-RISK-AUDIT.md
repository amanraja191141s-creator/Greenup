# SA Calculator — IP hygiene and originality audit (v78)

**Purpose:** reduce avoidable intellectual-property risk through independent branding, asset hygiene, source review and release documentation. This is an engineering audit, not a legal opinion, trademark clearance, or proof that every line of historical code was independently authored.

## Findings in the supplied v76 source package

- No `ClevCalc` or `Cleveni` name/string was found in the reviewed app HTML, CSS, JavaScript, server, manifest or README.
- The brand directory contains only `sa-calculator-icon.png`, the SA Calculator logo artwork supplied by the user for this project. No competitor logo or screenshot asset was found in that directory.
- The visible app identity, page title, manifest name, header and server user-agent identify SA Calculator.
- The product uses common calculator categories (arithmetic, currency, units, percentage, tax, date, fuel, loan/EMI, savings, tip and related utilities). The presence of common functions alone does not establish copying.
- Existing `sumaire_*` storage keys and `sumaire` internal selectors are retained for backwards compatibility. They are implementation/storage identifiers, not visible product branding. Renaming them without a migration would risk losing user settings/history.
- No source provenance file, contributor history, third-party licence inventory or side-by-side ClevCalc source/reference corpus was supplied. Therefore authorship of every historical source-code block, visual similarity across all screens, and third-party licence compliance cannot be conclusively verified from this ZIP alone.

## Engineering changes in v78

- Kept the independently maintained built-in currency estimate table available when a user launches offline without a prior cache.
- Clearly labels built-in estimates separately from live and dated cached rates to avoid implying that static fallback values are current market quotes.
- Added a regression test for the offline fallback.

## Historical engineering changes in v77

- Enabled non-blocking service-worker registration on HTTPS and localhost so the existing offline shell is actually activated.
- Bumped release metadata and service-worker cache namespace to v77 to prevent stale v76 shell reuse.
- Added explicit PNG/JPEG/WebP MIME types to the static server, including the supplied launcher/logo PNG.
- Added automated release gates for service-worker registration, logo MIME handling, competitor-brand string absence and brand asset inventory.
- Preserved existing local-storage keys and calculator logic to avoid destructive migrations.

## Required before public/commercial release

1. Maintain a source provenance ledger for each module: author, creation date, source/repository, and any borrowed code/licence.
2. Review all third-party packages, fonts, icon sets, APIs and datasets against their licences/terms; retain notices where required.
3. Compare the final screens against current ClevCalc screens using a documented screen-by-screen visual review. Do not copy distinctive compositions, wording, icons, illustrations, or assets.
4. Verify SA Calculator name/logo availability through Indian trademark searches and relevant classes; this package does not establish trademark availability.
5. Have an Indian IP professional review the final app and branding before commercial distribution.

## Legal research notes

The Indian Copyright Office explains that copyright protects original expression rather than ideas, procedures, methods of operation or mathematical concepts, and that computer programs can be registered as literary works. WIPO similarly distinguishes program expression from ideas and methods. This supports keeping common calculator functionality while independently creating code, text, graphics and expressive UI. It does not mean every GUI/layout is automatically free to copy; design, trademark, passing-off and other rights may still matter depending on facts and jurisdiction.

- India Copyright Office FAQ: https://copyright.gov.in/frmFAQ.aspx
- Copyright Act, 1957 (India): https://copyright.gov.in/Copyright_Act_1957/chapter_i.html
- WIPO, Copyright protection: https://www.wipo.int/en/web/copyright/protection



## v80 scope note
This release changes currency-provider integration and release metadata only. It does not establish legal clearance or independently verify authorship/licensing of every historical source file and asset. Continue maintaining the source-provenance register and obtain professional review before commercial publication.

## v80 whole-app and currency review
- Re-ran the release hygiene scan over the shipped app HTML, CSS, JavaScript, server, manifest and README: no competitor brand strings found in product-facing files; the only brand image in the brand directory is the SA Calculator artwork supplied for this project.
- Common calculator operations and tool categories are functional ideas/methods; their presence alone does not prove copying. Independent expression, source provenance, visual distinctiveness, third-party licence compliance and trademark clearance remain separate checks.
- Reworked currency data-date validation to reject impossible calendar dates and to validate each Frankfurter v2 row separately, because that endpoint may blend providers with different publication calendars.
- Official reference sources reviewed for v80: Frankfurter API v2 documentation (https://frankfurter.dev/), Fawaz Exchange API README and migration guide (https://github.com/fawazahmed0/exchange-api), India IP India copyright FAQs (https://ipindia.gov.in/pages/copyright/learn/faqs), and WIPO copyright overview (https://www.wipo.int/en/web/copyright/protection).
- No claim of legal clearance is made. A complete screen-by-screen visual comparison requires a current, lawful reference corpus and should be reviewed by an IP professional before commercial release.


## Prior v81 implementation note
- Currency cache now stores and independently revalidates observation dates for each currency; missing/stale pair dates are not reused.
- Public currency provider adapters reject missing, malformed, stale and future-dated quote timestamps.
- The optional server proxy rate-limit map now expires buckets and is size-capped.
- This implementation note is a technical change log, not legal clearance or a full source-provenance opinion.


## v86 release note

The v86 package includes a whole-app static integration audit and expanded automated checks for calculator-screen registration, settings action handlers, history retention and currency-provider provenance. This is not legal clearance, a trademark search, or a complete third-party licence review. The source-provenance ledger and professional review remain required before commercial distribution.


## v86 final whole-app review note
- v86 static integration tests cover 17 calculator screens, 12 settings groups, 15 theme palettes, registered menu/favorites screens, and all 33 distinct HTML action names.
- History protections and currency swap raw-value synchronization received additional regression checks after code review found edge cases.
- This remains an engineering hygiene review, not a legal opinion, trademark clearance, third-party licence audit or assurance of zero defects.

## v87 release note

- v87 extends the whole-app engineering audit to settings restoration, visible appearance-mode selection, local Help/Feedback dialogs, history capacity protections, currency source-merging rules and representative formula regression tests.
- The language control is explicitly scoped to navigation labels/titles; tool screens are not claimed to be fully localized.
- Feedback is copied/shared only after explicit user action and is not automatically uploaded.
- The audit remains an engineering hygiene review, not a trademark search, legal opinion, complete licence review, or assurance that all historical code and design elements are independently authored.


## v88 release note

- Currency refresh check and successful-update timestamps are stored locally only. They contain no API credentials or account identifiers. Display uses the device locale/timezone.


## v89 currency source-date handling

Provider observation dates remain attributed to the source response and are never replaced with local refresh timestamps. Multiple dated providers are now checked on refresh and the newest validated observation is selected per currency. This is a technical freshness improvement, not a guarantee of live/intraday market pricing or financial benchmark suitability.
