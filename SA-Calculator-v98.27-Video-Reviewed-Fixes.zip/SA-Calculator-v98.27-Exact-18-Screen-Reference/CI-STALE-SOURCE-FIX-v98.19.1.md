# CI stale-source fix — v98.19.1

## Evidence
The supplied Android screen recording shows Settings > About & Support reporting `v1.98.17-v98.17`. The current v98.19 source ZIP contains package version `1.98.19-v98.19`, an index title with that version, a v98.19 service-worker cache key, the native dark reference stylesheet, and the four-tab bottom navigation.

## Root cause
The earlier workflow selected `$GITHUB_WORKSPACE/package.json` unconditionally whenever it existed. It only searched uploaded ZIP archives when the repository root had no `package.json`. A stale extracted v98.17 source tree therefore took precedence over the newly uploaded v98.19 ZIP, and the APK was built from old files.

## Fix
Both workflow files now enumerate the repository-root project and uploaded `SA-Calculator-v*.zip` projects, read their actual `package.json` versions, compare numeric version components, and select the newest. Uploaded archives win ties. The selected package version is emitted as a workflow output, checked against the app's `index.html`, and included in the APK artifact name.

## Local checks
- Regression suite: 165 passed, 0 failed, 0 skipped.
- JavaScript syntax: PASS.
- `main.yml` and `android-apk.yml` YAML parse: PASS.
- `npm run build:web`: PASS.
- Generated web bundle contains v98.19 package marker, dark-reference CSS and bottom navigation: PASS.

## Remaining external verification
GitHub Actions must run with the corrected workflow and select `1.98.19-v98.19`. The resulting APK must then be installed and checked on the target Android phone. The local checks do not claim the remote Gradle build or physical-device test has already happened.
